import mongoose from 'mongoose'
import AuthModel from '../src/server/model/auth.model.js'
import { normalizeAdminEmail, requireServerEnv } from '../src/server/util/validation.mjs'

const main = async () => {
  const mongoUri = requireServerEnv('MONGODB_URI')
  const seedEmail = normalizeAdminEmail(process.env.ADMIN_INITIAL_EMAIL || process.env.ADMIN_EMAIL || '')
  const seedPassword = (process.env.ADMIN_INITIAL_PASSWORD || process.env.ADMIN_PASSWORD || '').trim()

  if (!seedPassword) {
    throw new Error('Missing required environment variable: ADMIN_INITIAL_PASSWORD')
  }

  await mongoose.connect(mongoUri, { bufferCommands: false, serverSelectionTimeoutMS: 15000 })

  const existingUser = await AuthModel.findOne({ email: seedEmail }).lean()
  if (existingUser) {
    console.log('Admin account already exists; no changes were made.')
    return
  }

  await AuthModel.create({
    fullname: 'Super Admin',
    email: seedEmail,
    password: seedPassword,
    role: 'super-admin',
    isActive: true
  })

  console.log('Initial administrator account created successfully.')
}

main()
  .catch((error) => {
    console.error(error.message)
    process.exitCode = 1
  })
  .finally(async () => {
    await mongoose.disconnect()
  })
